﻿using System.Data;
using System.IO;
using System.Net;
using System.Text;

namespace prova_pratica_002
{
    public class CsvFile
    {
        public string originalText;

        // Realiza uma solicitação para a uri especificada
        public string GetFileOnline(string uri) 
        {

            WebClient client = new WebClient();
            Stream stream = client.OpenRead(uri);

            // Muda a codificação do arquivo para que os caracteres especiais(ç, õ, etc.) sejam exibidos
            StreamReader reader = new StreamReader(stream, Encoding.UTF7);

            string CsvText = reader.ReadToEnd();
            return CsvText;
        }

        // Função utilizada como teste (abre o arquivo local)
        public string GetFileLocal(string Path)
        {
            var sr = new StreamReader(Path);
            string CsvText = sr.ReadToEnd();
            sr.Close();
            return CsvText;                
        }

        // Tabela os dados para exibição no dataGrid
        public DataTable GetDataSource(string text) 
        {
            // Cria uma tabela de dados, usada como data source para o dataGrid
            DataTable dt = new DataTable(); 

            string[] lines = text.Split('\r');

            string[] colNames = lines[0].Split(';'); 
            foreach (string name in colNames)
            {
                // if statement utilizado para posterior filtragem de valores
                if (name == "Estações Convencionais" || name == "Estações M2M" || name == "Total")
                {
                    // Atribuição do nome das colunas(caso inteiro)
                    dt.Columns.Add(new DataColumn(name, typeof(int))); 
                }
                else
                {
                    // Atribuição do nome das colunas(caso string)
                    dt.Columns.Add(new DataColumn(name));
                }
            }

            for (int n = 1; n < lines.Length - 1; n++)
            {
                string[] data = lines[n].Split(';');
                DataRow dr = dt.NewRow();

                for (int m = 0; m < colNames.Length; m++)
                {
                    dr[m] = data[m];
                }
                dt.Rows.Add(dr); // Atribuição dos valores da tabela
            }

            return dt;
        }
    }
    
}
