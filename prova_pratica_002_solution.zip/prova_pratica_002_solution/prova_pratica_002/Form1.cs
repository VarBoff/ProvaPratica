﻿using System;
using System.Text;
using System.Windows.Forms;

namespace prova_pratica_002
{
    public partial class Form1 : Form
    {
        CsvFile csvFile1;

        public Form1()
        {
            InitializeComponent();

            // uri para obter o acesso ao arquivo
            string uri = "http://www.anatel.gov.br/dadosabertos/PDA/Outorga/Esta%C3%A7%C3%B5es%20Licenciadas/Estacoes_SMGS.csv";

            // Cria uma nova classe "CsvFile" para melhor organização
            csvFile1 = new CsvFile();

            // Realiza uma solicitação para a uri especificada
            csvFile1.originalText = csvFile1.GetFileOnline(uri);

            // Passa a data source para o Grid
            dataGrid.DataSource = csvFile1.GetDataSource(csvFile1.originalText);
    
        }

        // Salva o arquivo no local desejado
        private void btnSalvar_Click(object sender, EventArgs e) 
        {
            // Abre uma caixa de dialogo para possibilidade de escolha do local do arquivo
            SaveFileDialog saveFileDialog1 = new SaveFileDialog(); 
            saveFileDialog1.InitialDirectory = Convert.ToString(Environment.SpecialFolder.MyDocuments);
            saveFileDialog1.Filter = "Microsoft Excel Comma Separated Values File (*.csv)|*.csv|All Files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;

            // Não salva caso o usuario feche a caixa de dialogo
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                System.IO.File.WriteAllText(saveFileDialog1.FileName, csvFile1.originalText, Encoding.UTF8); // Codifica de volta para evitar bugs
                MessageBox.Show("Salvo com êxito");
            }
        }
    }
}
